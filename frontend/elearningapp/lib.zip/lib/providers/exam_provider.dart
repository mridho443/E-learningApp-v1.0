import 'package:flutter/material.dart';
import '../services/exam_service.dart';

class ExamProvider with ChangeNotifier {
  List<dynamic> _exams = [];
  bool _isLoading = false;
  String? _errorMessage;

  List<dynamic> get exams => _exams;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  final ExamService _examService = ExamService();

  Future<void> fetchExams() async {
    _isLoading = true;
    notifyListeners();

    try {
      _exams = await _examService.fetchExams();
      _errorMessage = null;
    } catch (e) {
      _errorMessage = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addExam(
      String title, String description, String startDate, int duration) async {
    try {
      final newExam =
          await _examService.addExam(title, description, startDate, duration);
      _exams.add(newExam);
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
    }
  }

  Future<void> updateExam(int id, String title, String description,
      String startDate, int duration) async {
    try {
      await _examService.updateExam(
          id, title, description, startDate, duration);
      final index = _exams.indexWhere((exam) => exam['id'] == id);
      if (index != -1) {
        _exams[index] = {
          "id": id,
          "judul": title,
          "deskripsi": description,
          "tanggal_mulai": startDate,
          "durasi": duration,
        };
      }
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
    }
  }

  Future<void> deleteExam(int id) async {
    try {
      await _examService.deleteExam(id);
      _exams.removeWhere((exam) => exam['id'] == id);
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
    }
  }
}
