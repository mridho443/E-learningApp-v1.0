import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart'; // Untuk format tanggal
import '../providers/exam_provider.dart';
import 'add_exam_screen.dart';

class AdminExamsScreen extends StatelessWidget {
  // Fungsi untuk memformat tanggal
  String formatDate(String dateString) {
    try {
      final dateTime = DateTime.parse(dateString);
      return DateFormat('d MMMM y', 'id_ID')
          .format(dateTime); // Format: 1 Februari 2025
    } catch (e) {
      return dateString; // Kembalikan string asli jika parsing gagal
    }
  }

  @override
  Widget build(BuildContext context) {
    final examProvider = Provider.of<ExamProvider>(context);

    return Scaffold(
      appBar: AppBar(title: Text("Kelola Ujian")),
      body: examProvider.isLoading
          ? Center(child: CircularProgressIndicator())
          : examProvider.exams.isEmpty
              ? Center(child: Text("Tidak ada data ujian"))
              : ListView.builder(
                  itemCount: examProvider.exams.length,
                  itemBuilder: (context, index) {
                    final exam = examProvider.exams[index];
                    if (exam == null ||
                        exam['judul'] == null ||
                        exam['tanggal_mulai'] == null) {
                      return SizedBox
                          .shrink(); // Atau tampilkan widget placeholder
                    }
                    return ListTile(
                      title: Text(exam['judul'] ?? 'Judul Tidak Tersedia'),
                      subtitle: Text(
                          "Tanggal Mulai: ${formatDate(exam['tanggal_mulai'])}"),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(Icons.edit),
                            onPressed: () {
                              // Navigasi ke layar edit ujian
                            },
                          ),
                          IconButton(
                            icon: Icon(Icons.delete),
                            onPressed: () {
                              // Hapus ujian
                              examProvider.deleteExam(exam['id']);
                            },
                          ),
                        ],
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AddExamScreen(),
            ),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
