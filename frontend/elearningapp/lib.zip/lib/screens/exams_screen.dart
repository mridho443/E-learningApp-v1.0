import 'package:flutter/material.dart';
import 'admin_exams_screen.dart'; // Import AdminExamsScreen

class ExamsScreen extends StatelessWidget {
  final String role;

  ExamsScreen({required this.role});

  @override
  Widget build(BuildContext context) {
    // Jika role adalah admin, langsung tampilkan AdminExamsScreen
    if (role == 'admin') {
      return AdminExamsScreen();
    }

    // Jika bukan admin, tampilkan daftar ujian untuk siswa
    return Scaffold(
      appBar: AppBar(title: Text("Ujian")),
      body: Center(
        child: Text("Daftar ujian yang dapat diikuti siswa."),
      ),
    );
  }
}
