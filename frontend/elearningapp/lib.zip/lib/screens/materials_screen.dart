import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/materials_provider.dart';
import '../providers/auth_provider.dart';
import 'add_material_screen.dart';
import 'edit_material_screen.dart';

class MaterialsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final materialsProvider = Provider.of<MaterialsProvider>(context);

    // Cek role user (admin/student)
    final role =
        authProvider.user?.role ?? "student"; // Default student jika null

    // Jika belum memuat data, muat data
    if (!materialsProvider.isLoaded) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        materialsProvider.loadMaterials();
      });
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(
            role == "admin" ? "Kelola Materi Pelajaran" : "Materi Pelajaran"),
      ),
      body: role == "admin"
          ? AdminMaterialsView(materialsProvider: materialsProvider)
          : StudentMaterialsView(materialsProvider: materialsProvider),
    );
  }
}

class StudentMaterialsView extends StatelessWidget {
  final MaterialsProvider materialsProvider;

  StudentMaterialsView({required this.materialsProvider});

  @override
  Widget build(BuildContext context) {
    if (materialsProvider.isLoading) {
      return Center(
        child: CircularProgressIndicator(), // Tampilkan loading
      );
    }

    if (materialsProvider.errorMessage != null) {
      return Center(
        child: Text(materialsProvider.errorMessage!), // Tampilkan error
      );
    }

    if (materialsProvider.materials.isEmpty) {
      return Center(
        child: Text("Materi Kosong"), // Tampilkan jika kosong
      );
    }

    return RefreshIndicator(
      onRefresh: materialsProvider.loadMaterials,
      child: ListView.builder(
        itemCount: materialsProvider.materials.length,
        itemBuilder: (context, index) {
          final material = materialsProvider.materials[index];
          return Card(
            margin: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: ListTile(
              title: Text(material['judul']),
              subtitle: Text(material['deskripsi']),
              onTap: () {
                materialsProvider.downloadAndOpenFile(
                  material['file_url'].split('/').last,
                );
              },
            ),
          );
        },
      ),
    );
  }
}

class AdminMaterialsView extends StatelessWidget {
  final MaterialsProvider materialsProvider;

  AdminMaterialsView({required this.materialsProvider});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ElevatedButton.icon(
          onPressed: () {
            // Tambah materi
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => AddMaterialScreen()),
            );
          },
          icon: Icon(Icons.add),
          label: Text("Tambah Materi"),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: materialsProvider.loadMaterials,
            child: ListView.builder(
              itemCount: materialsProvider.materials.length,
              itemBuilder: (context, index) {
                final material = materialsProvider.materials[index];
                return Card(
                  margin: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: ListTile(
                    title: Text(material['judul']),
                    subtitle: Text(material['deskripsi']),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.edit),
                          onPressed: () {
                            // Edit materi
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      EditMaterialScreen(material: material)),
                            );
                          },
                        ),
                        IconButton(
                          icon: Icon(Icons.delete),
                          onPressed: () {
                            // Hapus materi
                            materialsProvider.deleteMaterial(material['id']);
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}
