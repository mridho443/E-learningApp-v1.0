import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; // Tambahkan Provider
import '../providers/auth_provider.dart';
import 'materials_screen.dart'; // Halaman Materi
import 'exams_screen.dart'; // Halaman Ujian
import 'grades_screen.dart'; // Halaman Nilai Ujian

class DashboardScreen extends StatelessWidget {
  final String role;

  DashboardScreen({required this.role});

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);

    return Scaffold(
      appBar: AppBar(
        title: Text("Dashboard"),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              authProvider.logout(); // Panggil logout dari AuthProvider
              Navigator.pushNamedAndRemoveUntil(
                  context, '/login', (route) => false);
            },
          ),
        ],
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (role == 'admin') ...[
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => MaterialsScreen()),
                      );
                    },
                    child: Text("Kelola Materi"),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ExamsScreen(role: role)),
                      );
                    },
                    child: Text("Kelola Ujian"),
                  ),
                ] else if (role == 'student') ...[
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => MaterialsScreen()),
                      );
                    },
                    child: Text("Materi Pelajaran"),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ExamsScreen(role: role)),
                      );
                    },
                    child: Text("Ikuti Ujian"),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => GradesScreen()),
                      );
                    },
                    child: Text("Nilai Ujian"),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
