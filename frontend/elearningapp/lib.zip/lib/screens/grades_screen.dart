import 'package:flutter/material.dart';

class GradesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Nilai Ujian")),
      body: Center(
        child: Text("Daftar nilai ujian siswa."), // Placeholder untuk nilai ujian
      ),
    );
  }
}
