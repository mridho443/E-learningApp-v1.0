import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:provider/provider.dart';
import '../providers/materials_provider.dart';

class EditMaterialScreen extends StatefulWidget {
  final Map<String, dynamic> material; // Data materi yang akan diedit

  EditMaterialScreen({required this.material});

  @override
  _EditMaterialScreenState createState() => _EditMaterialScreenState();
}

class _EditMaterialScreenState extends State<EditMaterialScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  File? _selectedFile; // File yang dipilih pengguna

  @override
  void initState() {
    super.initState();
    // Set nilai awal dari data materi yang ada
    _titleController.text = widget.material['judul'];
    _descriptionController.text = widget.material['deskripsi'];
  }

  /// Fungsi untuk memilih file (PDF atau file lainnya)
  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'], // Hanya izinkan file dengan ekstensi PDF
    );

    if (result != null && result.files.single.path != null) {
      setState(() {
        _selectedFile = File(result.files.single.path!);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Edit Materi")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _titleController,
                decoration: InputDecoration(labelText: "Judul"),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Judul tidak boleh kosong";
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _descriptionController,
                decoration: InputDecoration(labelText: "Deskripsi"),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Deskripsi tidak boleh kosong";
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: _pickFile,
                icon: Icon(Icons.attach_file),
                label: Text("Pilih File Baru"),
              ),
              if (_selectedFile != null)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10.0),
                  child: Text(
                    "File Baru: ${_selectedFile!.path.split('/').last}",
                    style: TextStyle(fontSize: 16),
                  ),
                )
              else
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10.0),
                  child: Text(
                    "File Lama: ${widget.material['file_url']}",
                    style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic),
                  ),
                ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () async {
                  print(widget.material);
                  if (_formKey.currentState!.validate()) {
                    // Gunakan file baru jika ada, atau file lama jika tidak ada file baru
                    final fileToUpload = _selectedFile;

                    await Provider.of<MaterialsProvider>(context, listen: false)
                        .updateMaterial(
                      widget.material['id'],
                      _titleController.text,
                      _descriptionController.text,
                      fileToUpload, // File baru atau null
                    );
                    Navigator.pop(context);
                  }
                },
                child: Text("Simpan"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
